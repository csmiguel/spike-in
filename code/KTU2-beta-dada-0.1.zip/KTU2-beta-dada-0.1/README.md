# KTU2
KTU2: The 2nd version of K-mer-based taxonomic clustering algorithm
